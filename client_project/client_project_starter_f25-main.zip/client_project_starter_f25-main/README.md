# Client_Project_Starter_Code
Starter code for the Fall 2025 & Winter 2026 Client Project
